## backend/resume_parser.py
import pdfplumber
import re
import pdfplumber
import pytesseract
from PIL import Image
import io

def extract_text_from_resume(filepath):
    """Extract text from a PDF file using pdfplumber (or OCR if needed)."""
    extracted_text = ""
    try:
        with pdfplumber.open(filepath) as pdf:
            for page in pdf.pages:
                text = page.extract_text()
                if text:
                    extracted_text += text + "\n"
        
        # If no text is found, attempt OCR (for scanned PDFs)
        if not extracted_text.strip():
            with pdfplumber.open(filepath) as pdf:
                for page in pdf.pages:
                    img = page.to_image(resolution=300)
                    img_byte_arr = io.BytesIO()
                    img.save(img_byte_arr, format='PNG')
                    extracted_text += pytesseract.image_to_string(Image.open(img_byte_arr))

        return extracted_text.strip()

    except Exception as e:
        return f"Error extracting text: {str(e)}"

def extract_email_from_text(text):
    """Extracts the first email found in resume text."""
    email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}"
    matches = re.findall(email_pattern, text)
    return matches[0] if matches else "No Email Found"

if __name__ == "__main__":
    sample_text = "Contact: test.user@example.com for job inquiries."
    print("Extracted Email:", extract_email_from_text(sample_text))
    print("Extracted Resume Text:", extract_text_from_resume("../data/resumes/sample.pdf"))