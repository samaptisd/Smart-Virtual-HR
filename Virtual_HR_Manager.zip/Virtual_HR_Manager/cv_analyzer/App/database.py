import mysql.connector
import os
from datetime import datetime

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "user": os.getenv("DB_USER", "root"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "ats_resume"),
}

def connect_db():
    return mysql.connector.connect(**DB_CONFIG)


def save_questions(resume_name, department, position, questions):
    try:
        db = connect_db()
        cursor = db.cursor()
        created_at = datetime.now()

        query = """
        INSERT INTO position_questions (resume_name, department, position, Q1, Q2, Q3, Q4, Q5, created_at)
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (resume_name, department, position, *questions, created_at)
        cursor.execute(query, values)
        db.commit()
        cursor.close()
        db.close()
    except Exception as e:
        print("Database error:", str(e))


def fetch_questions(position_name):
    try:
        db = connect_db()
        cursor = db.cursor(dictionary=True)
        query = "SELECT Q1, Q2, Q3, Q4, Q5 FROM position_questions WHERE position_name = %s ORDER BY created_at DESC LIMIT 1"
        cursor.execute(query, (position_name,))
        result = cursor.fetchone()
        cursor.close()
        db.close()
        return list(result.values()) if result else []
    except Exception as e:
        print("Database error:", str(e))
        return []


def save_interview(resume_name, position_name, responses):
    try:
        db = connect_db()
        cursor = db.cursor()
        created_at = datetime.now()
        for response in responses:
            query = """
            INSERT INTO response (resume_name, position_name, questions, response, score, created_at)
            VALUES (%s, %s, %s, %s, %s, %s)
            """
            values = (
                resume_name,
                position_name,
                response["question"],
                response["response"],
                response.get("score", "N/A"),
                created_at,
            )
            cursor.execute(query, values)
        db.commit()
        cursor.close()
        db.close()
    except Exception as e:
        print("Database error:", str(e))
