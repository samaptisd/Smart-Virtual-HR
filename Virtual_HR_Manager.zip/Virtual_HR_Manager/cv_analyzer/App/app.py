from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
import pandas as pd
import base64
import pymysql
import os
import io
from pyresparser import ResumeParser
from pdfminer3.layout import LAParams
from pdfminer3.pdfinterp import PDFResourceManager, PDFPageInterpreter
from pdfminer3.converter import TextConverter
from pdfminer3.pdfpage import PDFPage
import nltk
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import random
import string
import spacy
import secrets
from itsdangerous import URLSafeTimedSerializer
from werkzeug.utils import secure_filename
from datetime import datetime
from resume_parser import extract_text_from_resume
from question_generator import generate_questions
from flaskext.mysql import MySQL


nlp = spacy.load("en_core_web_sm")
nltk.download('stopwords')



app = Flask(__name__)
app.secret_key = ""
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  

# MySQL Configuration
app.config['MYSQL_HOST'] = ''
app.config['MYSQL_USER'] = ''
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = ''
app.config['MYSQL_PORT'] = 3306
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

# Email Configuration
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587
EMAIL_SENDER = ""
EMAIL_PASSWORD = ""

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Create upload directory if not exists
UPLOAD_FOLDER = './Uploaded_Resumes'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def get_db_connection():
    return pymysql.connect(
        host=app.config['MYSQL_HOST'],
        user=app.config['MYSQL_USER'],
        password=app.config['MYSQL_PASSWORD'],
        database=app.config['MYSQL_DB'],
        port=app.config['MYSQL_PORT'],
        cursorclass=pymysql.cursors.DictCursor
    )

class User(UserMixin):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

    def get_id(self):
        return str(self.id)


@login_manager.user_loader
def load_user(user_id):
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT * FROM users WHERE id = %s", (user_id,))
            user = cursor.fetchone()
            if user:
                return User(id=user['id'], username=user['username'], password=user['password'])
        return None
    except Exception as e:
        print(f"Error loading user: {e}")
        return None
    finally:
        conn.close()


def generate_token(username):
    serializer = URLSafeTimedSerializer(app.secret_key)
    return serializer.dumps(username, salt="email-confirmation")

def generate_random_username():
    """ Generate a random username with a prefix and random number """
    return f"user_{random.randint(1000, 9999)}"

def generate_random_password(length=12):
    chars = string.ascii_letters + string.digits + "!@#$%^&*()"
    return ''.join(secrets.choice(chars) for _ in range(length))

def pdf_reader(file_path):
    resource_manager = PDFResourceManager()
    fake_file_handle = io.StringIO()
    converter = TextConverter(resource_manager, fake_file_handle, laparams=LAParams())
    page_interpreter = PDFPageInterpreter(resource_manager, converter)
    
    with open(file_path, 'rb') as fh:
        for page in PDFPage.get_pages(fh, caching=True, check_extractable=True):
            page_interpreter.process_page(page)
        text = fake_file_handle.getvalue()
    
    converter.close()
    fake_file_handle.close()
    return text




@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        
        try:
            conn = get_db_connection()
            with conn.cursor() as cursor:
                cursor.execute('SELECT * FROM users WHERE username = %s', (username,))
                user = cursor.fetchone()
                
                if user and user['password'] == password:  # Direct comparison
                    user_obj = User(id=user['id'], username=user['username'], password=user['password'])
                    login_user(user_obj)
                    return redirect(url_for('index'))
                else:
                    flash('Invalid username or password', 'danger')
        except Exception as e:
            flash('Database error occurred', 'danger')
            print(f"Login error: {str(e)}")
        finally:
            conn.close()
    
    return render_template('login.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/recruiter', methods=['GET', 'POST'])
@login_required
def recruiter():
    if request.method == 'POST':
        try:
            department = request.form['department']
            position = request.form['position']
            job_description = request.form['job_description'].strip()
            resumes = request.files.getlist('resumes')
            
            if not all([department, position, job_description]) or not resumes:
                flash('All fields are required', 'danger')
                return redirect(request.url)
            
            job_keywords = set(job_description.lower().split())
            match_results = []
            created_at = datetime.now()

            for resume in resumes:
                if resume.filename == '':
                    continue
                
                filename = secure_filename(resume.filename)
                resume_path = os.path.join(UPLOAD_FOLDER, filename)
                resume.save(resume_path)
                
                # Parse resume
                resume_data = ResumeParser(resume_path).get_extracted_data()
                resume_text = pdf_reader(resume_path).lower()
                resume_keywords = set(resume_text.split())
                
                # Calculate match
                matched_keywords = job_keywords & resume_keywords
                match_percentage = (len(matched_keywords) / len(job_keywords)) * 100 if job_keywords else 0
                
                # Store results
                result = {
                    'resume_name': filename,
                    'Department': department,
                    'Position': position,
                    'Candidate Name': resume_data.get('name', 'N/A'),
                    'Email': resume_data.get('email', 'N/A'),
                    'Mobile': resume_data.get('mobile_number', 'N/A'),
                    'Match Percentage': round(match_percentage, 2),
                    'Predicted Designation': 'N/A',
                    'Matched Keywords': ', '.join(matched_keywords)
                }
                match_results.append(result)
                
                # Insert into database
                conn = get_db_connection()
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO resume_matches_ksa 
                        (resume_name, department, position, candidate_name, email, mobile, 
                         match_percentage, matched_keywords, created_at)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        filename, department, position, 
                        resume_data.get('name', 'N/A'),
                        resume_data.get('email', 'N/A'),
                        resume_data.get('mobile_number', 'N/A'),
                        round(match_percentage, 2),
                        ', '.join(matched_keywords),
                        created_at
                    ))
                    conn.commit()
                
                # Generate and store questions
                questions = generate_questions(resume_text, position)
                username = generate_random_username()
                password = generate_random_password()
                
                with conn.cursor() as cursor:
                    cursor.execute("""
                        INSERT INTO position_questions 
                        (resume_name, department, position, intro_text, Q1, Q2, Q3, Q4, Q5, 
                         created_at, email, user_name, password)
                        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    """, (
                        filename, department, position, "Tell me about yourself",
                        questions[0], questions[1], questions[2], questions[3], questions[4],
                        created_at, resume_data.get('email', 'N/A'), username, password
                    ))
                    conn.commit()
                conn.close()

            return render_template('recruiter_results.html', match_results=match_results)
        
        except Exception as e:
            flash(f'Error processing request: {str(e)}', 'danger')
            print(f"Recruiter route error: {str(e)}")
            return redirect(request.url)
    
    return render_template('recruiter.html')

@app.route('/dashboard')
@login_required
def dashboard():
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            # Get departments for filter
            cursor.execute("SELECT DISTINCT department FROM resume_matches_ksa")
            departments = [row['department'] for row in cursor.fetchall()]
            
            # Get filter parameter
            selected_dept = request.args.get('department', 'All')
            
            # Fetch data
            if selected_dept != "All":
                cursor.execute("""
                    SELECT * FROM resume_matches_ksa 
                    WHERE department = %s 
                    ORDER BY created_at DESC 
                    LIMIT 50
                """, (selected_dept,))
            else:
                cursor.execute("SELECT * FROM resume_matches_ksa ORDER BY created_at DESC LIMIT 50")
                
            data = cursor.fetchall()
            df = pd.DataFrame(data)
            csv_link = get_csv_download_link(df, 'resume_matches.csv') if not df.empty else None

        return render_template('dashboard.html', 
                             departments=departments,
                             selected_dept=selected_dept,
                             data=data,
                             csv_link=csv_link)
    
    except Exception as e:
        flash(f'Error loading dashboard: {str(e)}', 'danger')
        return redirect(url_for('index'))
    finally:
        conn.close()

def get_csv_download_link(df, filename):
    csv = df.to_csv(index=False)
    b64 = base64.b64encode(csv.encode()).decode()
    return f'<a href="data:file/csv;base64,{b64}" download="{filename}">Download CSV</a>'

@app.route('/update_status', methods=['POST'])
@login_required
def update_status():
    try:
        data = request.get_json()
        resume_id = data['id']
        new_status = data['status']
        email = data['email']
        
        conn = get_db_connection()
        with conn.cursor() as cursor:
            # Update status
            cursor.execute("""
                UPDATE resume_matches_ksa 
                SET status = %s 
                WHERE id = %s
            """, (new_status, resume_id))
            
            # Generate credentials if selected
            if new_status == "Selected":
                username = generate_random_username()
                password = generate_random_password()
                
                # Update position_questions table
                cursor.execute("""
                    UPDATE position_questions 
                    SET user_name = %s, password = %s 
                    WHERE email = %s
                """, (username, password, email))
                
                # Send email
                send_email(email, new_status, username, password)
            
            conn.commit()
        
        return jsonify({'success': True, 'message': 'Status updated successfully'})
    
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
    finally:
        conn.close()

def send_email(to_email, status, username, password):
    token = generate_token(username)
    login_link = url_for('login', token=token, _external=True)
    
    msg = MIMEMultipart()
    msg['From'] = EMAIL_SENDER
    msg['To'] = to_email
    msg['Subject'] = "Application Status Update"
    
    body = f"""
    Your application status has been updated to: {status}
    
    Temporary Credentials (valid for 24 hours):
    Username: {username}
    Password: {password}
    
    Login URL: {login_link}
    """
    
    msg.attach(MIMEText(body, 'plain'))
    
    try:
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
        server.starttls()
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.sendmail(EMAIL_SENDER, to_email, msg.as_string())
        server.quit()
    except Exception as e:
        print(f"Error sending email: {str(e)}")

@app.route('/get_departments', methods=['GET'])
@login_required
def get_departments():
    try:
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT department FROM master_ksa")
            departments = [row['department'] for row in cursor.fetchall()]
            return jsonify(departments)
    except Exception as e:
        return jsonify([])
    finally:
        conn.close()

@app.route('/get_positions', methods=['GET'])
@login_required
def get_positions():
    try:
        department = request.args.get('department')
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT DISTINCT position FROM master_ksa WHERE department = %s", (department,))
            positions = [row['position'] for row in cursor.fetchall()]
            return jsonify(positions)
    except Exception as e:
        return jsonify([])
    finally:
        conn.close()

@app.route('/get_key_skills', methods=['GET'])
@login_required
def get_key_skills():
    try:
        position = request.args.get('position')
        conn = get_db_connection()
        with conn.cursor() as cursor:
            cursor.execute("SELECT key_skill FROM master_ksa WHERE position = %s", (position,))
            skills = cursor.fetchone()
            return jsonify(skills['key_skill'] if skills else "")
    except Exception as e:
        return jsonify("")
    finally:
        conn.close()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5012, debug=True)