## backend/evaluation.py
import openai
import os

openai.api_key = os.getenv("OPENAI_API_KEY")

def evaluate_answer(response_text):
    """
    Evaluates a candidate's answer using OpenAI GPT-4.
    Returns a score and feedback.
    """
    prompt = f"Evaluate this interview response: '{response_text}'. Give a score (1-10) and feedback."

    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "You are an AI interview evaluator."},
                  {"role": "user", "content": prompt}]
    )

    feedback = response["choices"][0]["message"]["content"]
    return {"score": feedback.split('Score: ')[-1].strip(), "feedback": feedback}

if __name__ == "__main__":
    test_answer = "I have 5 years of experience in Python and Machine Learning."
    print(evaluate_answer(test_answer))
