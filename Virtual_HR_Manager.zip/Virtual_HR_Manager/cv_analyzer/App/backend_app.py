from flask import Flask, request, jsonify
from flask_cors import CORS
import os

# Import required modules
from question_generator import generate_questions
from evaluation import evaluate_answer
from database import save_interview, save_questions, fetch_questions
from resume_parser import extract_text_from_resume

app = Flask(__name__)
CORS(app)  # Enable CORS for frontend access

# Ensure the uploads folder exists
UPLOAD_FOLDER = "uploads/"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/')
def home():
    return "AI Interview Assistant API is running!"

@app.route('/upload_resume', methods=['POST'])
def upload_resume():
    """Handles resume upload, extracts text, generates questions, and saves them."""
    
    # Check if a file was uploaded
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400

    file = request.files['file']
    position = request.form.get("position", "Software Engineer")
    
    # Ensure file is a PDF
    if not file.filename.endswith(".pdf"):
        return jsonify({"error": "Only PDF files are allowed"}), 400

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(filepath)

    # Extract text from resume
    resume_text = extract_text_from_resume(filepath)
    if not resume_text or len(resume_text) < 100:
        return jsonify({"error": "Resume text extraction failed. Try another resume."}), 500

    resume_name = file.filename

    # Generate questions based on the resume text
    questions = generate_questions(resume_text, position)
    if len(questions) < 5:
        return jsonify({"error": "Not enough questions generated. Try another resume."}), 500

    # Save questions in database
    save_questions(resume_name, position, questions[:5])

    return jsonify({
        "message": "Resume uploaded and questions generated successfully!",
        "resume_name": resume_name,
        "position": position,
        "questions": questions[:5]
    })

@app.route('/fetch_questions', methods=['GET'])
def fetch():
    """Fetches the latest set of questions for a position from the database."""
    position = request.args.get("position", "Software Engineer")
    questions = fetch_questions(position)

    if questions:
        return jsonify({"questions": questions})
    else:
        return jsonify({"error": "No questions found"}), 404

@app.route('/evaluate', methods=['POST'])
def evaluate():
    """Evaluates the user's response using an AI scoring system."""
    data = request.get_json()
    response = data.get("response")
    score = evaluate_answer(response)

    return jsonify({
        "score": score,
        "feedback": f"AI Feedback: {response}"
    })

@app.route('/save_interview', methods=['POST'])
def save():
    """Saves interview responses to the database."""
    data = request.get_json()
    resume_name = data.get("resume_name", "Unknown Resume")
    position_name = data.get("position_name", "Unknown Position")
    responses = data.get("responses", [])

    save_interview(resume_name, position_name, responses)
    
    return jsonify({"message": "Interview saved successfully"})

if __name__ == '__main__':
    app.run(debug=True, port=5000)  # Ensure it runs on port 5000
