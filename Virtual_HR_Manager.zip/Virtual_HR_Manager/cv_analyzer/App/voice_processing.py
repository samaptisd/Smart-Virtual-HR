## backend/voice_processing.py
import openai
import whisper
import os
import pyttsx3

openai.api_key = os.getenv("OPENAI_API_KEY")

# Load Whisper model
model = whisper.load_model("base")

def transcribe_audio(audio_file):
    """
    Transcribes audio file to text using OpenAI Whisper.
    """
    audio_path = f"../data/audio/{audio_file.filename}"
    audio_file.save(audio_path)  # Save the file locally

    result = model.transcribe(audio_path)
    return result["text"]

def synthesize_speech(text):
    """
    Converts text to speech using pyttsx3 (offline TTS).
    """
    engine = pyttsx3.init()
    engine.say(text)
    engine.runAndWait()

if __name__ == "__main__":
    # Testing Speech-to-Text
    print(transcribe_audio("sample_audio.wav"))

    # Testing Text-to-Speech
    synthesize_speech("Hello! This is a test for AI Interview Assistant.")
