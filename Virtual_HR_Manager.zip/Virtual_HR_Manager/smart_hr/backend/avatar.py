import os
import streamlit as st
from flask import Flask, send_file, abort
import threading
import time

# Define avatar directory path
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
AVATAR_DIR = os.path.join(BASE_DIR, "avatars")
AVATAR_FILENAME = "AI-talking-avatar.gif"  # Replace with your GIF filename

# Ensure the avatars directory exists
if not os.path.exists(AVATAR_DIR):
    os.makedirs(AVATAR_DIR)

# Flask app setup
app = Flask(__name__)

@app.route('/avatar/<filename>')
def serve_avatar(filename):
    """Serve avatar GIF file."""
    file_path = os.path.join(AVATAR_DIR, filename)

    if os.path.exists(file_path):
        return send_file(file_path, mimetype="image/gif")  # ✅ Set correct MIME type for GIFs
    else:
        abort(404, "File not found")

# Function to run Flask in a separate thread
def run_flask():
    time.sleep(2)  # Allow Streamlit to initialize
    app.run(port=5001, debug=False, use_reloader=False)

# Start Flask server only once
if "flask_thread" not in st.session_state:
    flask_thread = threading.Thread(target=run_flask, daemon=True)
    flask_thread.start()
    st.session_state["flask_thread"] = flask_thread

# Construct the correct GIF URL
AVATAR_GIF_URL = f"http://127.0.0.1:5001/avatar/{AVATAR_FILENAME}"

# Streamlit UI
# st.title("🎭 AI Virtual HR Interview with Talking Avatar")

# Embed the talking avatar GIF
st.markdown(f"""
    <div style="text-align:center;">
        <img src="{AVATAR_GIF_URL}" alt="Talking Avatar" style="width: 400px; height: 300px; border-radius: 10px;">
    </div>
""", unsafe_allow_html=True)

# Show success message with clickable file URL
# st.success(f"✅ Avatar loaded from [Click to view GIF]({AVATAR_GIF_URL})")
