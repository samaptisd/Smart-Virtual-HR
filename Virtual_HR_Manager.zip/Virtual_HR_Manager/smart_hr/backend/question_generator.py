## backend/question_generator.py
import openai
import os
from dotenv import load_dotenv
from database import save_questions

# Load environment variables from .env file
load_dotenv()

# Retrieve OpenAI API key from environment variables
openai_api_key = os.getenv("OPENAI_API_KEY")
if not openai_api_key:
    raise ValueError("OpenAI API key is missing. Set it in a .env file or as an environment variable.")

openai.api_key = openai_api_key

def generate_questions(resume_text, position):
    """Generates at least 5 questions from the extracted resume text."""
    try:
        # Your existing logic to generate questions
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": f"Generate interview questions for a {position}."},
                {"role": "user", "content": resume_text}
            ],
            max_tokens=250
        )

        questions = response['choices'][0]['message']['content'].strip().split("\n")
        questions = [q.strip() for q in questions if q.strip()]

        # Ensure we have at least 5 questions
        if len(questions) < 10:
            return []

        return questions[:5]

    except Exception as e:
        print(f"Error in question generation: {str(e)}")
        return []


def generate_and_store_questions(resume_text, email, position):
    """Generates questions based on position and stores them in the database."""
    questions = generate_questions(resume_text, position)
    save_questions(email, position, questions)
    return questions

if __name__ == "__main__":
    sample_resume_text = "Software Engineer with 5 years of experience in Python and AI."
    sample_position = "Software Engineer"
    print(generate_questions(sample_resume_text, sample_position))