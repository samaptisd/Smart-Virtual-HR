document.addEventListener("DOMContentLoaded", function() {
    fetchQuestion();
});

// Function to fetch a question from the backend
function fetchQuestion() {
    fetch("/fetch_questions")
        .then(response => response.json())
        .then(data => {
            if (data.questions && data.questions.length > 0) {
                document.getElementById("question-text").innerText = data.questions[0];  // Show first question
            } else {
                document.getElementById("question-text").innerText = "No questions available.";
            }
        })
        .catch(error => {
            console.error("Error fetching questions:", error);
            document.getElementById("question-text").innerText = "Error loading question.";
        });
}

// Function to record audio (speech-to-text)
function recordAudio() {
    alert("Voice recording is not implemented yet.");
}

// Function to submit response
function submitResponse() {
    let response = document.getElementById("response").value;
    let question = document.getElementById("question-text").innerText;

    if (!response.trim()) {
        alert("Please enter or record your answer before submitting.");
        return;
    }

    fetch("/submit_response", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ question: question, response: response })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Response submitted successfully!");
            fetchQuestion();  // Load next question
            document.getElementById("response").value = "";  // Clear input field
        } else {
            alert("Error submitting response.");
        }
    })
    .catch(error => {
        console.error("Error submitting response:", error);
    });
}


