from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import mysql.connector
import pyttsx3
import threading
from datetime import datetime


app = Flask(__name__)
app.secret_key = "Aludecor"

DB_CONFIG = {
    "host": "",
    "user": "samapti",
    "password": "",
    "database": "ats_resume"
}

# BACKEND_URL = "http://127.0.0.1:5000"

responses = {}  # Stores candidate answers


def speak_text(text):
    """Function to convert text to speech."""
    try:
        engine = pyttsx3.init()
        engine.setProperty("rate", 150)
        engine.setProperty("volume", 1.0)
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print("❌ Error in text-to-speech:", str(e))


@app.route("/", methods=["GET", "POST"])
def login():
    """User login page."""
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]

        if authenticate_user(username, password):
            session["logged_in"] = True
            session["user_name"] = username
            responses[session["user_name"]] = []  # Reset responses
            return redirect(url_for("interview"))
        else:
            return render_template("login.html", error="Invalid username or password.")

    return render_template("login.html")


def authenticate_user(username, password):
    """Check if user credentials are valid."""
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM position_questions WHERE user_name=%s AND password=%s", (username, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        return user is not None
    except Exception as e:
        print(f"Database connection error: {e}")
        return False


@app.route("/fetch_questions")
def fetch_questions():
    """Fetch interview questions from MySQL."""
    if "user_name" not in session:
        return redirect(url_for("login"))

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)
        query = """
            SELECT intro_text,Q1, Q2, Q3, Q4, Q5 
            FROM position_questions 
            WHERE user_name = %s 
            ORDER BY created_at DESC 
            LIMIT 1
        """
        cursor.execute(query, (session["user_name"],))
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if result:
            valid_questions = [q for q in result.values() if q and q.strip()]
            return jsonify(valid_questions if valid_questions else ["No questions found."])
        else:
            return jsonify(["No questions available for this user."])
    except Exception as e:
        print("Database error:", str(e))
        return jsonify(["Error fetching questions. Please try again later."])


@app.route("/speak_question", methods=["POST"])
def speak_question():
    """API to speak the current question."""
    data = request.json
    question = data.get("question", "")

    if question:
        threading.Thread(target=speak_text, args=(question,)).start()
        return jsonify({"status": "success", "message": "Speaking question..."})
    
    return jsonify({"status": "error", "message": "No question provided"})

def evaluate_answer(answer):
    """Simple heuristic-based scoring (Can be replaced with AI-based evaluation)"""
    
    # Define keywords that indicate a good answer
    good_keywords = ["experience", "project", "team", "problem-solving", "developed", "implemented", "achieved"]
    
    # Define words that may indicate a weak response
    weak_keywords = ["yes", "no", "okay", "maybe", "somewhat", "not sure"]

    # Convert answer to lowercase
    answer_lower = answer.lower()

    # Assign score based on keyword presence
    if any(word in answer_lower for word in good_keywords):
        return 10  # Good answer
    elif any(word in answer_lower for word in weak_keywords):
        return 2  # Not a good answer
    else:
        return 5  # Neutral answer



@app.route("/save_response", methods=["POST"])
def save_response():
    try:
        data = request.get_json()

        if not data or "question" not in data or "answer" not in data or "user_name" not in data:
            return jsonify({"status": "error", "message": "Invalid request format"}), 400

        user_name = data["user_name"].strip()
        question = data["question"].strip()
        answer = data["answer"].strip()

        if not question or not answer:
            return jsonify({"status": "error", "message": "Question or answer missing"}), 400

        # **Automatically Evaluate Score**
        score = evaluate_answer(answer)

        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor()

        cursor.execute("""
            INSERT INTO interview_responses (user_name, questions, response, score, created_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, (user_name, question, answer, score))

        conn.commit()
        cursor.close()
        conn.close()

        return jsonify({"status": "success", "message": "Response saved successfully", "score": score})

    except Exception as e:
        print("❌ Error saving response:", str(e))
        return jsonify({"status": "error", "message": str(e)}), 500



@app.route("/interview")
def interview():
    """Interview page."""
    if "logged_in" not in session:
        return redirect(url_for("login"))

    return render_template("interview.html", username=session["user_name"])

@app.route("/submit_interview", methods=["POST"])
def submit_interview():
    try:
        data = request.get_json()
        user_name = data.get("user_name", "").strip()
        responses = data.get("responses", [])

        if not user_name or not responses:
            return jsonify({"status": "error", "message": "Missing user name or responses."})

        return jsonify({"status": "success"})  # ✅ Return success

    except Exception as e:
        print("❌ Error:", str(e))
        return jsonify({"status": "error", "message": str(e)})

@app.route("/thank_you")
def thank_you():
    """Render the Thank You page after successful submission."""
    return render_template("thank_you.html")

@app.route("/fetch_responses", methods=["GET"])
def fetch_responses():
    """Retrieve all saved responses for a user from the database."""
    user_name = request.args.get("user_name", "").strip()

    if not user_name:
        return jsonify({"status": "error", "message": "User name is missing."})

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        cursor.execute("""
            SELECT questions, response FROM interview_responses WHERE user_name = %s
        """, (user_name,))
        results = cursor.fetchall()

        cursor.close()
        conn.close()

        if not results:
            return jsonify({"status": "error", "message": "No responses found."})

        return jsonify({"status": "success", "responses": results})

    except Exception as e:
        print("❌ Error fetching responses:", str(e))
        return jsonify({"status": "error", "message": str(e)})
    

@app.route("/summary_report")
def summary_report():
    """Generate a summary report for the logged-in user."""
    if "user_name" not in session:
        return redirect(url_for("login"))

    user_name = session["user_name"]

    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        cursor = conn.cursor(dictionary=True)

        # Fetch total questions and sum of scores
        cursor.execute("""
            SELECT COUNT(*) AS total_questions, count(questions) AS total_score 
            FROM interview_responses 
            WHERE user_name = %s
        """, (user_name,))
        
        result = cursor.fetchone()
        cursor.close()
        conn.close()

        if not result or result["total_questions"] == 0:
            return render_template("summary_report.html", user_name=user_name, score_percentage=0, total_questions=0)

        # Calculate score percentage
        max_possible_score = result["total_questions"] * 10  # Assuming 10 is the max score per answer
        score_percentage = (result["total_score"] / max_possible_score) * 100

        return render_template("summary_report.html", user_name=user_name, score_percentage=round(score_percentage, 2), total_questions=result["total_questions"])

    except Exception as e:
        print("❌ Error fetching summary report:", str(e))
        return render_template("summary_report.html", user_name=user_name, score_percentage=0, total_questions=0, error=str(e))

@app.route("/speak_hr_intro", methods=["POST"])
def speak_hr_intro():
    """HR intro text-to-speech."""
    data = request.json
    text = data.get("text", "")

    if text:
        threading.Thread(target=speak_text, args=(text,)).start()
        return jsonify({"status": "success"})
    
    return jsonify({"status": "error", "message": "No text provided"})
@app.route("/save_candidate_intro", methods=["POST"])
def save_candidate_intro():
    """Saves the candidate's introduction to the database."""
    data = request.json
    user_name = data.get("user_name")
    intro = data.get("intro")

    if not user_name or not intro:
        return jsonify({"status": "error", "message": "Missing data"}), 400

    # Here, you can store the intro in the database (Example: MySQL)
    print(f"Saving Candidate Intro: {user_name} -> {intro}")  # Debugging

    return jsonify({"status": "success", "message": "Candidate introduction saved successfully"})

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port='5010')
