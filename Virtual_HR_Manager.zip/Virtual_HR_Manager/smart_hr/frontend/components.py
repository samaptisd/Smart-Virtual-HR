import streamlit as st

def header():
    st.markdown("""
    <h1 style='text-align: center; color: blue;'>AI Interview Assistant</h1>
    """, unsafe_allow_html=True)

def sidebar():
    st.sidebar.title("Navigation")
    page = st.sidebar.radio("Go to", ["Upload Resume", "Interview Questions", "Results"])
    return page

def display_questions(questions):
    st.subheader("Generated Interview Questions")
    for idx, question in enumerate(questions, start=1):
        st.write(f"{idx}. {question}")

def display_results(score, feedback):
    st.subheader("Interview Feedback")
    st.write(f"**Score:** {score}/10")
    st.write(f"**Feedback:** {feedback}")